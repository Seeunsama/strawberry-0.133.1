---
title: Generics
---

# Generics

Documentation coming soon
