from .concrete_type import ConcreteType as ConcreteType


__all__ = ["ConcreteType"]
