import strawberry


@strawberry.type
class LaziestType:
    something: bool
