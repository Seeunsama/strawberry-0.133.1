class OperationNameResultInterface:
    id: str

class OperationNameResult:
    interface: OperationNameResultInterface
