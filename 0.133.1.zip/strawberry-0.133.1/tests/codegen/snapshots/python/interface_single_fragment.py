class OperationNameResultInterfaceBlogPost:
    id: str
    title: str

class OperationNameResult:
    interface: OperationNameResultInterfaceBlogPost
