from typing import Optional

class OperationNameResultOptionalPerson:
    name: str

class OperationNameResult:
    optional_person: Optional[OperationNameResultOptionalPerson]
