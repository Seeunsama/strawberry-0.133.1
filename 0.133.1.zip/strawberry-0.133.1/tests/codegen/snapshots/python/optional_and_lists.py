from typing import List, Optional

class OperationNameResult:
    optional_int: Optional[int]
    list_of_int: List[int]
    list_of_optional_int: List[Optional[int]]
    optional_list_of_optional_int: Optional[List[Optional[int]]]
