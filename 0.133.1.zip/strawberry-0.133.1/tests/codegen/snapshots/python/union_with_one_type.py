class OperationNameResultUnionAnimal:
    age: int

class OperationNameResult:
    union: OperationNameResultUnionAnimal
