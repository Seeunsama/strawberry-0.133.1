class OperationNameResultPerson:
    name: str

class OperationNameResult:
    person: OperationNameResultPerson
