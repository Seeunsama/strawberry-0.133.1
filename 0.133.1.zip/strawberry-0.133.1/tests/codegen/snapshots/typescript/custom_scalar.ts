type JSON = string

type OperationNameResult = {
    json: JSON
}
