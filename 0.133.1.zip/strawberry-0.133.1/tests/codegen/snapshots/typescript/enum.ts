enum Color {
    RED = "RED",
    GREEN = "GREEN",
    BLUE = "BLUE",
}

type OperationNameResult = {
    enum: Color
}
