type OperationNameResultInterface = {
    id: string
}

type OperationNameResult = {
    interface: OperationNameResultInterface
}
