type OperationNameResultInterfaceBlogPost = {
    id: string
    title: string
}

type OperationNameResult = {
    interface: OperationNameResultInterfaceBlogPost
}
