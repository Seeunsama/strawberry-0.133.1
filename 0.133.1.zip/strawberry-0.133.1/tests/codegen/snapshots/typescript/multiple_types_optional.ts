type OperationNameResultOptionalPerson = {
    name: string
}

type OperationNameResult = {
    optional_person: OperationNameResultOptionalPerson | undefined
}
