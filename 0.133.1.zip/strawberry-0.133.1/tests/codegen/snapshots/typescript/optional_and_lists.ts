type OperationNameResult = {
    optional_int: number | undefined
    list_of_int: number[]
    list_of_optional_int: (number | undefined)[]
    optional_list_of_optional_int: (number | undefined)[] | undefined
}
