type OperationNameResultUnionAnimal = {
    age: number
}

type OperationNameResult = {
    union: OperationNameResultUnionAnimal
}
