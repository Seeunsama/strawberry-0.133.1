type OperationNameResultPerson = {
    name: string
}

type OperationNameResult = {
    person: OperationNameResultPerson
}
