def typeless_resolver():
    return []
